const display = document.querySelector("#display");
const calculateBtn = document.querySelector("#calculate");

calculateBtn.addEventListener("click", () => {
    const day = parseInt(document.getElementById("day").value);
    const month = parseInt(document.getElementById("month").value);
    const year = parseInt(document.getElementById("year").value);

    if (isNaN(day) || isNaN(month) || isNaN(year)) {
        display.innerText = "Please enter a valid date";
        return;
    }

    const dob = new Date(year, month - 1, day);
    const today = new Date();

    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
        age--;
    }

    if (age < 0) {
        display.innerText = "Date of Birth cannot be in the future";
    } else {
        display.innerText = `Your age is ${age} years`;
    }
});

const themeToggleBtn = document.querySelector(".theme-toggler");
const calculator = document.querySelector(".calculator");
const toggleIcon = document.querySelector(".toggler-icon");
let isDark = true;

themeToggleBtn.onclick = () => {
    calculator.classList.toggle("dark");

    if (isDark) {
        toggleIcon.classList.remove("bi-moon");
        toggleIcon.classList.add("bi-sun");
        toggleIcon.style.transform = "rotate(360deg)";
    } else {
        toggleIcon.classList.remove("bi-sun");
        toggleIcon.classList.add("bi-moon");
        toggleIcon.style.transform = "rotate(360deg)";
    }
    
    isDark = !isDark;
};
